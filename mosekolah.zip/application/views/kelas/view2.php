<table class="table table-bordered">
    <tr><td width="100">Program Kelas</td><td> <?php echo inputan('text', 'nama','col-sm-4','Nama kelas ..', 1, '','');?></td></tr>
     <tr><td>Wali</td><td> <?php echo inputan('text', 'nama','col-sm-4','Nama kelas ..', 1, '','');?></td></tr>
      <tr><td>No Izin</td><td> <?php echo inputan('text', 'nama','col-sm-4','Nama kelas ..', 1, '','');?></td></tr>
</table>
<hr>

<table class="table table-bordered">
    <tr><td width="100">Program Kelas</td><td> <?php echo inputan('text', 'nama','col-sm-4','Nama kelas ..', 1, '','');?></td></tr>
     <tr><td>Wali</td><td> <?php echo inputan('text', 'nama','col-sm-4','Nama kelas ..', 1, '','');?></td></tr>
      <tr><td>No Izin</td><td> <?php echo inputan('text', 'nama','col-sm-4','Nama kelas ..', 1, '','');?></td></tr>
</table>
<hr>