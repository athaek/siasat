<?php
class message extends CI_Controller{
    
    function index()
    {
        echo "anda tidak boleh akses ke halaman ini";
    }
    
}
